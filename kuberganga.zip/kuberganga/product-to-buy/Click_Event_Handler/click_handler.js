document.addEventListener("DOMContentLoaded", function () {
  const buttons = document.querySelectorAll(".buy-btn");

  buttons.forEach(button => {
    button.addEventListener("click", function () {
      const productId = this.getAttribute("data-product-id");

      // Fetch catalog info via AJAX
      fetch(`catalog.php?product_id=${productId}`)
        .then(response => response.text())
        .then(data => {
          document.getElementById("catalog").innerHTML = data;
          document.getElementById("catalog").style.display = "block";
        })
        .catch(error => console.error("Error loading catalog:", error));
    });
  });
});